#include "dispersion.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Crea un fichero hash inicialmente vacio seg�n los criterios especificados en la pr�ctica
// Primera tarea a realizar para  crear un fichero organizado mediante DISPERSI�N
void creaHvacio(char *fichHash)
{ FILE *fHash;
  tipoCubo cubo;
  int j;
  int numCubos =CUBOS+CUBOSDESBORDE;

  memset(&cubo,0,sizeof(cubo));

  fHash = fopen(fichHash,"wb");
  for (j=0;j<numCubos;j++) fwrite(&cubo,sizeof(cubo),1,fHash);
  fclose(fHash);
}
// Lee el contenido del fichero hash organizado mediante el método de DISPERSIÓN según los criterios
// especificados en la práctica. Se leen todos los cubos completos tengan registros asignados o no. La
// salida que produce esta función permite visualizar el método de DISPERSIÓN

int leeHash(char *fichHash)
{ FILE *f;
  tipoCubo cubo;
  int j,i=0;
  size_t numLee;

   f = fopen(fichHash,"rb");
   rewind(f);
   fread(&cubo,sizeof(cubo),1,f);
   while (!feof(f)){
	for (j=0;j<C;j++) {
        if (j==0)    	printf("Cubo %2d (%2d reg. ASIGNADOS)",i,cubo.numRegAsignados);
        else  	printf("\t\t\t");
	if (j < cubo.numRegAsignados) 
		    printf("\t%s %s %s %s %s\n",
	    		cubo.reg[j].dni,
			cubo.reg[j].nombre,
			cubo.reg[j].ape1,
		  	cubo.reg[j].ape2,
  	                cubo.reg[j].provincia);
	else printf ("\n");
        }
       i++;
       fread(&cubo,sizeof(cubo),1,f);
   }
   fclose(f);
   return i;
}

int creaHash(char *fichEntrada,char *fichHash)
{
  FILE *fEntrada,*fHash;
  tipoAlumno reg;
  tipoCubo cubo,cuboDesborde;
  int i,k=0,numCubo,numDesb=0;

  creaHvacio(fichHash);
  fEntrada = fopen(fichEntrada,"rb");
  if(NULL == fEntrada) 
  {
    printf("ERROR. No se puede abrir el fichero %s\n",fichEntrada);
    return -1;
  }

  fHash = fopen(fichHash,"r+b");
  if(NULL == fHash)
   {
    printf("ERROR. No se puede abrir el fichero %s\n",fichHash);
    return -1;
  }

  fread(&reg,sizeof(reg),1,fEntrada);

  while(!feof(fEntrada))
  {
	numCubo = ((atoi(reg.dni))%CUBOS);
	fseek(fHash,numCubo*sizeof(cubo),SEEK_SET);
	fread(&cubo,sizeof(cubo),1,fHash);
	i=cubo.numRegAsignados;
	if(i>=C)
	{
  		numDesb++;
		cubo.numRegAsignados++;
		 //gestionar desborde
		//meter los sobrantes en los cubos del área de desborde
		fseek(fHash,(CUBOS)*sizeof(tipoCubo),SEEK_SET);
		fread(&cuboDesborde,sizeof(tipoCubo),1,fHash);
		i=cuboDesborde.numRegAsignados;
		k=0;
		if(i>=C){
			while(i>=C){
				cuboDesborde.numRegAsignados++;
				fseek(fHash,(CUBOS+k)*sizeof(cubo),SEEK_SET);
				fwrite(&cuboDesborde,sizeof(cubo),1,fHash);
		     	fread(&cuboDesborde,sizeof(cubo),1,fHash);
		     	i=cuboDesborde.numRegAsignados;
				 	
		     	k++;
			}
			cuboDesborde.reg[i]=reg;
			cuboDesborde.numRegAsignados++;
		}else{
			cuboDesborde.reg[i]=reg;
			cuboDesborde.numRegAsignados++;
		}
		fseek(fHash,(CUBOS+k)*sizeof(cubo),SEEK_SET);
		fwrite(&cuboDesborde,sizeof(cubo),1,fHash);
	}
	else
	{
 	  cubo.reg[i]=reg;
	  cubo.numRegAsignados++;
	}
	fseek(fHash,numCubo*sizeof(tipoCubo),SEEK_SET);
	fwrite(&cubo,sizeof(tipoCubo),1,fHash);

	fread(&reg,sizeof(reg),1,fEntrada);
  }
  fclose(fEntrada);
  fclose(fHash);
  return numDesb;
}

int buscaReg(FILE *fHash, tipoAlumno *reg,char *dni){
	tipoCubo cubo;
  	int i,k=0,numCubo=0;
  	
  	numCubo = ((atoi(dni))%CUBOS);
  	fseek(fHash,numCubo*sizeof(tipoCubo),SEEK_SET);
  	fread(&cubo,sizeof(cubo),1,fHash);
  	for(i=0;i<cubo.numRegAsignados && i<5;i++){
  		if(atoi(dni)==atoi(cubo.reg[i].dni)){
  			*reg=cubo.reg[i];
  			return numCubo;
  		}
  	}
  	numCubo=CUBOS-1;
  	fseek(fHash,CUBOS*sizeof(tipoCubo),SEEK_SET);
  	while(cubo.numRegAsignados>C){
  		numCubo++;
  		fread(&cubo,sizeof(cubo),1,fHash);
  		for(i=0;i<cubo.numRegAsignados && i<5;i++){
	  		if(atoi(dni)==atoi(cubo.reg[i].dni)){
	  			*reg=cubo.reg[i];
	  			return numCubo;
	  		}
  		}
  		
  	}
  	return -1;
}

int insertarReg(FILE *f, tipoAlumno *reg){
  tipoCubo cubo,cuboDesborde;
  int i,k=0,numCubo,flag=0;
  
  
	numCubo = ((atoi(reg->dni))%CUBOS);
	fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
	fread(&cubo,sizeof(tipoCubo),1,f);
	i=cubo.numRegAsignados;
	if(i>=C){
		flag=1;
		cubo.numRegAsignados++;
		fseek(f,CUBOS*sizeof(tipoCubo),SEEK_SET);
		fread(&cubo,sizeof(tipoCubo),1,f);
		i=cubo.numRegAsignados;
		while(i>=C && k<CUBOSDESBORDE){
			cubo.numRegAsignados++;
			fread(&cubo,sizeof(tipoCubo),1,f);
			i=cubo.numRegAsignados;
			k++;
		}
  		if(k>=CUBOSDESBORDE){
  			retrocederNumReg(f,numCubo);
  			return -1;
  		}else{
  			cubo.numRegAsignados++;
  			cubo.reg[i]=*reg;
  		}
  	}else{
  		cubo.numRegAsignados++;
  		cubo.reg[i]=*reg;
  	}
  	fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
  	fwrite(&cubo,sizeof(tipoCubo),1,f);
  	if(!flag){
  		return numCubo;
  	}else{
  		return CUBOS+k;
  	}
}

void retrocederNumReg(FILE * f,int numCubo){
	/*Esta función sólo se ejecutará en el caso de que
	el cubo destino este lleno y los de desborde también*/
	tipoCubo cubo;
	int k=0;
	
	fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
	fread(&cubo,sizeof(tipoCubo),1,f);
	cubo.numRegAsignados--;
	fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
	fwrite(&cubo,sizeof(tipoCubo),1,f);
	
	while(k<CUBOSDESBORDE){
		fseek(f,(CUBOS+k)*sizeof(tipoCubo),SEEK_SET);
		fread(&cubo,sizeof(tipoCubo),1,f);
		cubo.numRegAsignados--;
		fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
		fwrite(&cubo,sizeof(tipoCubo),1,f);
		k++;
	}
}














