#include "dispersion.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void creaHvacio(char *fichHash)
{ FILE *fHash;
  tipoCubo cubo;
  int j;
  int numCubos =CUBOS+CUBOSDESBORDE;

  memset(&cubo,0,sizeof(cubo));

  fHash = fopen(fichHash,"wb");
  for (j=0;j<numCubos;j++) fwrite(&cubo,sizeof(cubo),1,fHash);
  fclose(fHash);
}


int leeHash(char *fichHash)
{ FILE *f;
  tipoCubo cubo;
  int j,i=0;
  size_t numLee;

   f = fopen(fichHash,"rb");
   rewind(f);
   fread(&cubo,sizeof(cubo),1,f);
   while (!feof(f)){
	for (j=0;j<C;j++) {
        if (j==0)    	printf("Cubo %2d (%2d reg. ASIGNADOS)",i,cubo.numRegAsignados);
        else  	printf("\t\t\t");
	if (j < cubo.numRegAsignados) 
		    printf("\t%s %s %s %s %s\n",
	    		cubo.reg[j].dni,
			cubo.reg[j].nombre,
			cubo.reg[j].ape1,
		  	cubo.reg[j].ape2,
  	                cubo.reg[j].provincia);
	else printf ("\n");
        }
       i++;
       fread(&cubo,sizeof(cubo),1,f);
   }
   fclose(f);
   return i;
}

int creaHash(char *fichEntrada,char *fichHash)
{
  FILE *fEntrada,*fHash;
  tipoAlumno reg;
  tipoCubo cubo,cuboDesborde;
  int i,k=0,numCubo,numDesb=0;

  creaHvacio(fichHash);
  fEntrada = fopen(fichEntrada,"rb");
  if(NULL == fEntrada) 
  {
    printf("ERROR. No se puede abrir el fichero %s\n",fichEntrada);
    return -1;
  }

  fHash = fopen(fichHash,"r+b");
  if(NULL == fHash)
   {
    printf("ERROR. No se puede abrir el fichero %s\n",fichHash);
    return -1;
  }

  fread(&reg,sizeof(reg),1,fEntrada);

  while(!feof(fEntrada))
  {
	numCubo = ((atoi(reg.dni))%CUBOS);
	fseek(fHash,numCubo*sizeof(cubo),SEEK_SET);
	fread(&cubo,sizeof(cubo),1,fHash);
	i=cubo.numRegAsignados;
	if(i>=C)
	{
  		numDesb++;
		cubo.numRegAsignados++;
		fseek(fHash,(CUBOS)*sizeof(tipoCubo),SEEK_SET);
		fread(&cuboDesborde,sizeof(tipoCubo),1,fHash);
		i=cuboDesborde.numRegAsignados;
		k=0;
		if(i>=C){
			while(i>=C){
				cuboDesborde.numRegAsignados++;
				fseek(fHash,(CUBOS+k)*sizeof(cubo),SEEK_SET);
				fwrite(&cuboDesborde,sizeof(cubo),1,fHash);
		     	fread(&cuboDesborde,sizeof(cubo),1,fHash);
		     	i=cuboDesborde.numRegAsignados;
				 	
		     	k++;
			}
			cuboDesborde.reg[i]=reg;
			cuboDesborde.numRegAsignados++;
		}else{
			cuboDesborde.reg[i]=reg;
			cuboDesborde.numRegAsignados++;
		}
		fseek(fHash,(CUBOS+k)*sizeof(cubo),SEEK_SET);
		fwrite(&cuboDesborde,sizeof(cubo),1,fHash);
	}
	else
	{
 	  cubo.reg[i]=reg;
	  cubo.numRegAsignados++;
	}
	fseek(fHash,numCubo*sizeof(tipoCubo),SEEK_SET);
	fwrite(&cubo,sizeof(tipoCubo),1,fHash);

	fread(&reg,sizeof(reg),1,fEntrada);
  }
  fclose(fEntrada);
  fclose(fHash);
  return numDesb;
}

int buscaReg(FILE *fHash, tipoAlumno *reg,char *dni){
	tipoCubo cubo;
  	int i,k=0,numCubo=0;
  	
  	numCubo = ((atoi(dni))%CUBOS);
  	fseek(fHash,numCubo*sizeof(tipoCubo),SEEK_SET);
  	fread(&cubo,sizeof(cubo),1,fHash);
  	for(i=0;i<cubo.numRegAsignados && i<5;i++){
  		if(atoi(dni)==atoi(cubo.reg[i].dni)){
  			*reg=cubo.reg[i];
  			return numCubo;
  		}
  	}
  	numCubo=CUBOS-1;
  	fseek(fHash,CUBOS*sizeof(tipoCubo),SEEK_SET);
  	while(cubo.numRegAsignados>C){
  		numCubo++;
  		fread(&cubo,sizeof(cubo),1,fHash);
  		for(i=0;i<cubo.numRegAsignados && i<5;i++){
	  		if(atoi(dni)==atoi(cubo.reg[i].dni)){
	  			*reg=cubo.reg[i];
	  			return numCubo;
	  		}
  		}
  		
  	}
  	return -1;
}

int insertarReg(FILE *f, tipoAlumno *reg){
  tipoCubo cubo,cuboDesborde;
  int i,k=0,numCubo,flag=0;
  
  
	numCubo = ((atoi(reg->dni))%CUBOS);
	fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
	fread(&cubo,sizeof(tipoCubo),1,f);
	i=cubo.numRegAsignados;
	if(i>=C){
		flag=1;
		cubo.numRegAsignados++;
		fseek(f,CUBOS*sizeof(tipoCubo),SEEK_SET);
		fread(&cubo,sizeof(tipoCubo),1,f);
		i=cubo.numRegAsignados;
		while(i>=C && k<CUBOSDESBORDE){
			cubo.numRegAsignados++;
			fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
			fwrite(&cubo,sizeof(tipoCubo),1,f);
			fread(&cubo,sizeof(tipoCubo),1,f);
			i=cubo.numRegAsignados;
			k++;
		}
  		if(k>=CUBOSDESBORDE){
  			fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
			fread(&cubo,sizeof(tipoCubo),1,f);
			cubo.numRegAsignados--;
			fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
			fwrite(&cubo,sizeof(tipoCubo),1,f);
			
			while(k<CUBOSDESBORDE){
				fseek(f,(CUBOS+k)*sizeof(tipoCubo),SEEK_SET);
				fread(&cubo,sizeof(tipoCubo),1,f);
				cubo.numRegAsignados--;
				fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
				fwrite(&cubo,sizeof(tipoCubo),1,f);
				k++;
			}
  			return -1;
  		}else{
  			cubo.numRegAsignados++;
  			cubo.reg[i]=*reg;
  		}
  	}else{
  		cubo.numRegAsignados++;
  		cubo.reg[i]=*reg;
  	}
  	fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
  	fwrite(&cubo,sizeof(tipoCubo),1,f);
  	if(!flag){
  		return numCubo;
  	}else{
  		return CUBOS+k;
  	}
}

int eliminarReg(char *fichero, char *dni){
	FILE * f;
	int numCubo,h,i,j,k,encontrado=0;
	tipoCubo cubo,cubo2;
	tipoAlumno *reg,reg2;
	char * dni2;
	
	f = fopen(fichero,"r+b");	
	if(NULL == f)
	{
		printf("ERROR. No se puede abrir el fichero %s\n",f);
		return -2;
	}
	
	numCubo = buscaReg(f,&reg2,dni);
	if(numCubo==-1){
		puts("El registro no se encuentra en el fichero hash");
		fclose(f);
		return numCubo;
	}else{
	
	fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
	fread(&cubo,sizeof(tipoCubo),1,f);
	if(numCubo>=CUBOS){
			i=cubo.numRegAsignados;
			for(j=0;j<i && j<C;j++){
				if(atoi(cubo.reg[j].dni)==atoi(reg2.dni)){
					if(cubo.numRegAsignados<=C){
						cubo.reg[j]=cubo.reg[i-1];
						cubo.numRegAsignados--;
						k=numCubo;
						while(k>CUBOS){
							fseek(f,(--k)*sizeof(tipoCubo),SEEK_SET);
							fread(&cubo2,sizeof(tipoCubo),1,f);
							cubo2.numRegAsignados--;
							fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
							fwrite(&cubo2,sizeof(tipoCubo),1,f);						
						}
					}else{			
						do{
							fread(&cubo2,sizeof(tipoCubo),1,f);
							cubo2.numRegAsignados--;
							fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
							fwrite(&cubo2,sizeof(tipoCubo),1,f);
						}while(cubo2.numRegAsignados+1>C);
						
						cubo.numRegAsignados--;
						cubo.reg[j]=cubo2.reg[cubo2.numRegAsignados];
						fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
						fwrite(&cubo2,sizeof(tipoCubo),1,f);
						k=numCubo;
						while(k>CUBOS){
							fseek(f,(--k)*sizeof(tipoCubo),SEEK_SET);
							fread(&cubo2,sizeof(tipoCubo),1,f);
							cubo2.numRegAsignados--;
							fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
							fwrite(&cubo2,sizeof(tipoCubo),1,f);						
						}
					}
					
					fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
					fwrite(&cubo,sizeof(tipoCubo),1,f);
					fclose(f);
					return numCubo;	
				}
			}	
				
	}else{
		i=cubo.numRegAsignados;
		if(i<=C){
			for(j=0;j<=i;j++){
				if((atoi(cubo.reg[j].dni))==(atoi(reg2.dni))){
					cubo.reg[j]=cubo.reg[i-1];
					cubo.numRegAsignados--;
					fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
					fwrite(&cubo,sizeof(tipoCubo),1,f);
					fclose(f);
					return numCubo;
				}
			}
		}else{
			for(j=0;j<=i;j++){
				if((atoi(cubo.reg[j].dni))==(atoi(dni))){
					cubo.numRegAsignados--;
					break;
				}
			}
			k=0;
			fseek(f,(CUBOS+k)*sizeof(tipoCubo),SEEK_SET);
			do{
				fread(&cubo2,sizeof(tipoCubo),1,f);
				i=cubo2.numRegAsignados;
				for(h=0;h<=i;h++){
					dni2=cubo2.reg[h].dni;
					if((atoi(dni2)%CUBOS)==numCubo){
						cubo.reg[j]=cubo2.reg[h];
						fseek(f,numCubo*sizeof(tipoCubo),SEEK_SET);
						fwrite(&cubo,sizeof(tipoCubo),1,f);
						encontrado=1;
						break;
					}
				}
				cubo2.numRegAsignados--;
				fseek(f,(CUBOS+k)*sizeof(tipoCubo),SEEK_SET);
				fwrite(&cubo2,sizeof(tipoCubo),1,f);
				k++;
			}while(k<CUBOSDESBORDE && !encontrado);
			
			if(cubo2.numRegAsignados+1>C){		
				fread(&cubo,sizeof(tipoCubo),1,f);
				while(cubo.numRegAsignados>C){
					cubo.numRegAsignados--;
					fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
					fwrite(&cubo,sizeof(tipoCubo),1,f);
					fread(&cubo,sizeof(tipoCubo),1,f);
				}
				cubo2.reg[h]=cubo.reg[cubo.numRegAsignados-1];
				cubo.numRegAsignados--;
				fseek(f,(-1)*sizeof(tipoCubo),SEEK_CUR);
				fwrite(&cubo,sizeof(tipoCubo),1,f);
			}else{
				cubo2.reg[j]=cubo2.reg[cubo2.numRegAsignados+1];
			}
			fseek(f,(CUBOS+k-1)*sizeof(tipoCubo),SEEK_SET);
			fwrite(&cubo2,sizeof(tipoCubo),1,f);
			fclose(f);
			return numCubo;			
		}
		
	}
	fclose(f);
	return -1;
	}
}













