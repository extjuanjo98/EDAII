#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arbol.h"
#include "genArbol.h"

int main(void)
{ Arbol arbol,arbol2;
  int sustituciones;
  char ex_postfija[11];
  char ex_postfija2[11];
/* Generaci�n del �rbol algebraico */
  strcpy(ex_postfija,"AB+CDE+**\0");
  strcpy(ex_postfija2,"AB+MDE+**\0");
  arbol = genArbol(ex_postfija);
  arbol2 = genArbol(ex_postfija2);
/* Recorrido en amplitud o por niveles */
   amplitud(arbol);
   amplitud(arbol2);
/* Aplicaci�n de algunas operaciones y recorridos al �rbol ejemplo */

  
  printf("Recorrido en PRE_ORDEN: ");
  preOrden(arbol);
  printf("\n");

  printf("Recorrido en ORDEN: ");
  enOrden(arbol);
  printf("\n");
  printf("Recorrido en POST_ORDEN: ");
  postOrden(arbol);
  printf("\n");
  printf("Debe coinicidir con la expresi�n postfija inicial\n");

  printf("El �rbol tiene %d nodos \n", numNodos(arbol));
  printf("y altura: %d\n",altura(arbol));
  printf("El numero de nodos hoja es %d\n",numNodosHoja(arbol));
  printf("El numero de nodosinternos es %d\n",numNodosInternos(arbol));
  printf("Numero de hijos unicos es %d\n",numHijoUnico(arbol));
  printf("Los Arboles son similares? %d\n",similares(arbol,arbol2));
  printf("Los Arboles son equivalentes? %d\n",equivalentes(arbol,arbol2));

  printf("El valor m�ximo es %c y el m�nimo %c\n",(buscarMax(arbol))->info,(buscarMin(arbol))->info);


  printf("El �rbol tiene %d nodos\n", numNodos(arbol));
  arbol = anula(arbol);
  printf("Despu�s de anula el arbol queda vacio, por tanto la altura ser� 0.\n");
  if (altura(arbol)!=-1)		// Cuidado con definici�n de altura
     printf("El �rbol no se ha anulado correctamente\n");
  else
     printf("O.K. Parece que la operaci�n anula funciona!!!\n");

  
   

/* Evaluaci�n de un �rbol algebraico: operandos entre '0' y '9'*/

  strcpy(ex_postfija,"23+713+**\0");
  arbol = genArbol(ex_postfija);
  //printf("evalua: %d\n", evaluar(arbol));
  printf("Recorrido en PRE_ORDEN (prefija): ");
  preOrden(arbol);
  printf("\n");
  printf("Recorrido en ORDEN(infija): ");
  enOrden(arbol);
  printf("\n");
  printf("Recorrido en POST_ORDEN(postfija): ");
  postOrden(arbol);
  printf("\n");

  printf("Ahora sustituiremos los 3 por 9\n");
  sustituciones=sustiuye(arbol,'3','9');
  printf("ARBOL DESPUES DE SUSTITUIR\n");
  printf("Se ha sustituido %d veces \n",sustituciones);
  printf("Recorrido en PRE_ORDEN (prefija): ");
  preOrden(arbol);
  printf("\n");
  printf("Recorrido en ORDEN(infija): ");
  enOrden(arbol);
  printf("\n");
  printf("Recorrido en POST_ORDEN(postfija): ");
  postOrden(arbol);
  printf("\n");

  printf("\nARBOL ESPECULAR\n");
  arbol2=especular(arbol);

  printf("Recorrido en PRE_ORDEN (prefija): ");
  preOrden(arbol2);
  printf("\n");
  printf("Recorrido en ORDEN(infija): ");
  enOrden(arbol2);
  printf("\n");
  printf("Recorrido en POST_ORDEN(postfija): ");
  postOrden(arbol2);
  printf("\n");
  

/* Aplicar a este arbol las funciones del ejercicio 2 */
  return 0;
}
