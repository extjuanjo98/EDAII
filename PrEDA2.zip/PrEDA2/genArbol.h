#include "arbol.h"
Arbol genArbol(char *exPostfija);

