#include <stdio.h> 
#include <stdlib.h>
#include "genArbol.h"
#include "arbol.h"
#include "pila.h"

Arbol genArbol(char *exPostfija){
      Arbol a;
      Pila p;
      int i;
      char simbolo;
      pilaCreaVacia(&p);
      simbolo=exPostfija[0];
      i=0;
      while(simbolo!='\0'){
         switch(simbolo){
            case '+':
            case '*':
                a=creaNodo(simbolo);
                a->der=pilaSuprime(&p);
                a->izq=pilaSuprime(&p);
                pilaInserta(&p,a);
                break;
            default:
                a=creaNodo(simbolo);
                pilaInserta(&p,a);
                break;
         }
         i++;
         simbolo=exPostfija[i];
      }
      a=pilaSuprime(&p);
      return a;
}
