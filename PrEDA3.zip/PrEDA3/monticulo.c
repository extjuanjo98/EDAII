#include"monticulo.h"

void iniciaMonticulo(Monticulo *m)
{
	m->tamanno=0;
}

int vacioMonticulo(Monticulo m)
{
	if(m.tamanno==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void filtradoDescendente(Monticulo *m, int i)
{
	int hijo,finFiltrado=0;
	tipoElemento temp;

	while(2*i<=m->tamanno && !finFiltrado) //Controla que tenga un hijo
	{
		hijo=2*i;
		if(hijo!=m->tamanno)	//Controla que tenga hijo derecho tambien
		{
			if(m->elemento[hijo+1].clave<m->elemento[hijo].clave)
			{
				hijo+=1;
			}
		}
		if(m->elemento[i].clave>m->elemento[hijo].clave) 
		{
			temp=m->elemento[hijo];
			m->elemento[hijo]=m->elemento[i];
			m->elemento[i]=temp;
			i=hijo;
		}
		else
		{
			finFiltrado=1;
		}
	}
}

void filtradoAscendente(Monticulo *m, int i)
{
	tipoElemento temp;

	while((m->elemento[i/2]).clave>(m->elemento[i]).clave && i!=1)
	{
		temp=m->elemento[i];
		m->elemento[i]=m->elemento[i/2];
		m->elemento[i/2]=temp;
		i/=2;
	}
}

int insertar(tipoElemento x, Monticulo *m)
{
	int i;

	if(m->tamanno==MAXIMO)
	{
		return -1;
	}
	else
	{
		m->tamanno+=1;
		i=m->tamanno;
		m->elemento[i]=x;
		filtradoAscendente(m,i);
	}
}

int eliminarMinimo(Monticulo *m, tipoElemento *minimo)
{
	int i;
	if(vacioMonticulo(*m))
	{
		return -1;
	}
	else
	{
		*minimo=m->elemento[1];
		m->elemento[1]=m->elemento[m->tamanno];
		m->tamanno-=1;
		i=1;
		filtradoDescendente(m,i);
	}

	return 0;
}

void decrementarClave(int pos, tipoClave cantidad, Monticulo *m)
{
	m->elemento[pos].clave-=cantidad;

	filtradoAscendente(m,pos);
}

void incrementarClave(int pos, tipoClave cantidad, Monticulo *m)
{
	m->elemento[pos].clave+=cantidad;

	filtradoDescendente(m,pos);
}

int esMonticulo(Monticulo m)
{
	int i=1,activo=1;

	while(2*i<m.tamanno)
	{
	
		if(2*i!=m.tamanno)
		{
			if(m.elemento[i].clave>m.elemento[2*i].clave || m.elemento[i].clave>m.elemento[2*i+1].clave)
				activo=0;
		}
		else
		{
			if(m.elemento[i].clave>m.elemento[2*i].clave)
				activo=0;
			
		}
	i*=2;
	}

	return activo;
}

void crearMonticulo(Monticulo *m){
	int i,n;
	n=m->tamanno;

	for(i=n/2;i>=1;i--)
	{
		filtradoDescendente(m,i);
	}
}


void heapsort(Monticulo *m){
	tipoElemento vector[m->tamanno];
	int nElementos=m->tamanno;
	int i;
	tipoElemento elemento;

	crearMonticulo(m);
	
	for(i=0;i<nElementos;i++){
		eliminarMinimo(m,&elemento);
		vector[i]=elemento;
	}
	for(i=0;i<nElementos;i++){
		insertar(vector[i],m);
	}
}
